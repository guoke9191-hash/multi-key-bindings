package us.kenny.config;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import us.kenny.ConfigManager;
import us.kenny.GlobalToggleManager;

/** Small optional configuration screen exposed through Mod Menu. */
public final class GlobalConfigScreen extends Screen {
    private final Screen parent;
    private Button enabledButton;
    private Button keyButton;
    private boolean waitingForKey;

    public GlobalConfigScreen(Screen parent) {
        super(Component.translatable("multi-key-bindings.config.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        this.enabledButton = this.addRenderableWidget(Button.builder(enabledText(), button -> {
            GlobalToggleManager.setEnabled(!GlobalToggleManager.isEnabled());
            button.setMessage(enabledText());
        }).bounds(center - 100, this.height / 2 - 34, 200, 20).build());

        this.keyButton = this.addRenderableWidget(Button.builder(keyText(), button -> {
            waitingForKey = true;
            button.setMessage(Component.translatable("multi-key-bindings.config.press_key"));
        }).bounds(center - 100, this.height / 2 - 8, 200, 20).build());

        this.addRenderableWidget(Button.builder(Component.translatable("gui.done"), button -> onClose())
                .bounds(center - 100, this.height / 2 + 24, 200, 20).build());
    }

    private static Component enabledText() {
        return Component.translatable("multi-key-bindings.config.enabled",
                Component.translatable(GlobalToggleManager.isEnabled() ? "options.on" : "options.off"));
    }

    private static Component keyText() {
        return Component.translatable("multi-key-bindings.config.toggle_key",
                GlobalToggleManager.getToggleKey().getDisplayName());
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (waitingForKey) {
            if (keyCode == 256) {
                waitingForKey = false;
                keyButton.setMessage(keyText());
                return true;
            }
            GlobalToggleManager.setToggleKey(InputConstants.Type.KEYSYM.getOrCreate(keyCode));
            ConfigManager.saveConfigFile();
            waitingForKey = false;
            keyButton.setMessage(keyText());
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }
}
