package us.kenny;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import us.kenny.core.MultiKeyBinding;

/** Global master switch for Multi Key Bindings. */
public final class GlobalToggleManager {
    private static boolean enabled = true;
    private static InputConstants.Key toggleKey = InputConstants.Type.KEYSYM.getOrCreate(GLFW.GLFW_KEY_LEFT_ALT);

    private GlobalToggleManager() {}

    public static boolean isEnabled() { return enabled; }
    public static InputConstants.Key getToggleKey() { return toggleKey; }

    public static void setToggleKey(InputConstants.Key key) {
        if (key != null && key != InputConstants.UNKNOWN) {
            toggleKey = key;
            ConfigManager.saveConfigFile();
        }
    }

    public static void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (!enabled) {
            for (MultiKeyBinding binding : MultiKeyBindingManager.getKeyBindings()) {
                binding.release();
            }
        }
        announce();
        ConfigManager.saveConfigFile();
    }

    public static void toggle() { setEnabled(!enabled); }

    public static void load(boolean value, String keyName) {
        enabled = value;
        if (keyName != null && !keyName.isBlank()) {
            try { toggleKey = InputConstants.getKey(keyName); }
            catch (RuntimeException ignored) { toggleKey = InputConstants.Type.KEYSYM.getOrCreate(GLFW.GLFW_KEY_LEFT_ALT); }
        }
    }

    private static void announce() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.translatable(enabled
                    ? "multi-key-bindings.global.enabled" : "multi-key-bindings.global.disabled"), true);
        }
    }
}
